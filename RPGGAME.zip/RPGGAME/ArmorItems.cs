﻿namespace RPGGAME
{
    public class ArmorItems : BaseItem
    {
    }
}