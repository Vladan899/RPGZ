﻿namespace RPGGAME
{
    public interface StatAttribute
    {
         float Value { get; set; }
         float Name { get; set; }
    }
}